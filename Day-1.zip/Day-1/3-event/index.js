console.log("handing web server events");
//This http module is used to handle http request and response.
var http = require('http');

/*
//////////////////////
///////////Step A:::Request Event
//////////////////////
//Step A:: Create a  simple server not handing any event, and on hitting the url it will show the header details in the
//in the console
// To create an http serever
var server = http.createServer();
//To handle a client request
server.on('request',function(req,res){
    console.log("Request Recieved::",req.headers);
    res.end("Thanks I got your request");
})
//To set listener host and port
server.listen(3456,'localhost',function(){
    console.log("Http server listening to port 3456");
});
*/

//////////////////////
///////////Step B:::Upgrade Event
//////////////////////
//Step A:: Create a  simple server not handing any event, and on hitting the url it will show the header details in the
//in the console
// To create an http serever
var server = http.createServer();
//To handle a client request
server.on('request',function(req,res){
    console.log("Request Recieved::",req.headers);
    res.end("Thanks I got your request");
})

server.on('upgrade',function(req,socket,head){
    console.log("upgrade the connection to web socket connection");
})

//To set listener host and port
server.listen(3456,'localhost',function(){
    console.log("Http server listening to port 3456");
});




/*
var connect = require('connect');
var bodyParser = require('body-parser');

var app = connect().use(
    bodyParser.urlencoded({extended:true})
    ).use(function(req,res){
        var parsedInfo ={};
        parsedInfo.firstName = req.body.userFirstName;
        parsedInfo.lastName = req.body.userLastName;
        res.end("User info parsed from the form::"+parsedInfo.firstName +""+ parsedInfo.lastName);
})
*/


//console.log("Server responsing to port 3456");