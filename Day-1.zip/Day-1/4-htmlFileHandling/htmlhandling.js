console.log("Serving statis files");

var connect = require('connect');//it helps to connect to an http server
var serveStatic = require('serve-static');//it helps to load static html file from the mention directory
//here in our case the directory is myPublicFolder
var app = connect().use(serveStatic('myPublicFolder')).use(function(req,res){
    console.log("Welcome to our demo app");
}).listen(3456);
console.log("Server responsing to port 3456");