console.log("working with query string");
var queryString = require('querystring');
var baseURL = "http://localhost:3456/path/employee";
var queryObject ={
    empID:'1',
    empName:'Monirul'
}

var stringFromObject = queryString.stringify(queryObject);
//var stringFromObject = queryString.stringify(queryObject,";",":");//to add sperator in the query

console.log("URL Constructed from string::::"+baseURL+"?"+stringFromObject);

