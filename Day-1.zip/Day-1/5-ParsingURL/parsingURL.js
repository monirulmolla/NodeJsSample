console.log("working with url parsing");
var url = require('url');
//////////////////
////Step A::parsing an url
//////////////////
//Simple paring an URL
var testURL = "http://localhost:3456/path/employee?userId=1&userName=Monirul";
//Step A1::parse request url
//var parseObject =url.parse(testURL);//it will parse the request url

//Step A2: parse request query parameter as an object
var parseObject =url.parse(testURL,true);//if true it will break the query parameter as an object
console.log(parseObject);

//Step A3::construct the request url from the object
var urlString = url.format(parseObject);//
console.log("ReConsturcted URL:::"+urlString);