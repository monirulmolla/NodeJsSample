///This is a client to send a request from this client to the node server
//It mentioned step by step how we can send a request from a client to to node server and also how we can get
// a response back from the server using calback function.
//In the first step we are sending a normal form request with two input parameter as json data
//and in the second option we are sending an image file along with the normal form data.


//The request module is used to send a request
var request = require('request');

//the fs module is used to read a file
var fs = require('fs');
/*
/////////////////////
////STEP A::::::::::Norma data
////////////////////
//A simple form data

var data ={
    userFirstName:'Monirul',
    userLastName:'Molla'
}


//To get a response from  the server used callback function in post method
var callback = function(error,response,body){
    if(error) console.log(error);
    else console.log(body);
}
 //Step A1::::::::To get the data simply by passing the form data appending the post method
 request.post('http://localhost:3456').form(data);

 //Step A2:::::::://By passing the form data as a parameter in the post method
 //request.post('http://localhost:3456',{form:data});

 //Step A3:::::::://By passing the form data as a parameter in the post method
 //By passing the form data as a parameter in the post method and get a response back from the server
 // request.post("http://localhost:3456",{form:data},callback);
*/





/////////////////////
////STEP B::::::::::File upload
////////////////////
////A simple form data along with file
var data ={
    userFirstName:'Monirul',
    userLastName:'Molla',
    myBuffer: new Buffer([1]),//buffer for passing file data
    myFile:fs.createReadStream(__dirname+'/images/rose.jpg')//read stream containing file data to pass
}

//To send a file using post method
var postData ={
    url:'http://localhost:3456',
    formData:data
}

request.post(postData,optionalCallback = function(error,response,body){
    if(error) console.log(error);
    else console.log(body);
});