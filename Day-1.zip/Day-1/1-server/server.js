//This is a node server which handing post request with normal parameter and files
//This function can used by both the option mentioned in the client.js

//the express method is used to handle post request
var express = require("express");

//the formidable is used to handle files send in post request
var formidable = require('formidable');


var app = express();

app.use(function(req,res){
    if(req.method.toLocaleLowerCase()=="post"){
       var form = new formidable.IncomingForm();

       //configure the form
        //__dirname will provide the root directory name
        form.uploadDir = __dirname + '/uploads';
        form.keepExtensions = true;//it will set the original file extn if true
        form.type ='multipart';

        //parse fields
        form.parse(req,function(error,fields, files){
            var firstName = fields.userFirstName;
            var lastName = fields.userLastName;
            console.log("user info parsed from form:"+firstName +" "+lastName);
            res.writeHead(200, {'Content-Type':'text/plain'})
            res.end("Form data recieved");

            return;
        })

    }
});

var port =3456;
app.listen(port);
console.log("Server responsing to port 3456");
