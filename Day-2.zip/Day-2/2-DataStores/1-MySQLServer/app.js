console.log("Connecting to a MYSQL server");
var mysql = require("mysql");
var _ = require("underscore");

var connection = mysql.createConnection({
    user:'root',
    password:'root',
    database:'nodejs',
    host:'localhost',
    post:'3306'
});


connection.connect(function(error){
    if(error){
        throw new Error("could not connect to MYSL server");
    }
});

////////////////
//Step A1:Get data
////////////////

/*
var queryString = "select * from fruits";
connection.query(queryString,function(err,rows,fields){
    if(err){
        throw new Error("Error in performing query");
    } else{
        _.each(rows,function(row){
            console.log("ID:"+row.ID,"NAME:"+ row.NAME,"Description: "+ row.DESCRIPTION);
        });
    }
});
*/

////////////////
//Step A2:Insert data
////////////////
/*
var insertString = "INSERT INTO fruits SET ?";
var insertObj ={ID:'5',NAME:'Grapes',DESCRIPTION:'This is grapes'};
var updateString = connection.format(insertString,insertObj);
connection.query(updateString,function(err,result){
    if(err){
        throw new Error("Error in performing query");
    } else{
            console.log("Result:"+result);
    }
});
*/


/*
////////////////
//Step A3:Update data
////////////////
var updateQuery ="UPDATE fruits SET NAME = ?, DESCRIPTION =? WHERE ID = ?";
var updateData =['Grapes', 'This is grapes', '3'];
connection.query(updateQuery,updateData ,function (error, results, fields) {
    if(error){
        throw new Error("Error in performing query");
    } else{
        console.log("Result:"+results);
    }
});
*/
////////////////
//Step A2:DElete data
////////////////
var updateQuery ="DELETE FROM fruits WHERE ID = ?";
var updateData =['3'];
connection.query(updateQuery,updateData ,function (error, results, fields) {
    if(error){
        throw new Error("Error in performing query");
    } else{
        console.log("Result:"+results.toString());
    }
});

connection.end(function(err){
 console.log("Connection Ended");
});