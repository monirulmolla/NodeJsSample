console.log("Connecting to a MongoDB server");


/*
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/nodejs';

var insertDocument = function(db, insertObj,callback) {
    db.collection('fruits').insert( {"ID" : "2",
        "NAME" : "Banana",
        "DESCRIPTION" : "This is banana"}, function(err, result) {
        assert.equal(err, null);
        console.log("Inserted a document into the restaurants collection.");
        callback();
    });
};

var dataObj ={"ID" : "2",
    "NAME" : "Banana",
    "DESCRIPTION" : "This is banana"};

MongoClient.connect(url, function(err, db) {
    assert.equal(null, err);
    insertDocument(db,dataObj, function() {
        db.close();
    });
});

*/

var mongo = require("mongoskin");

mongoose.connect('mongodb://localhost:27017/nodejs');

var db = mongoose.connection;
db.on('error', console.error.bind(console,'connection error'));
db.once('open',function(error,result){
    console.log("db is connected");
    var fruitSchema = mongoose.Schema({
        ID:String,
        NAME:String,
        DESCRIPTION:String
    })

    var fruits = mongoose.model('fruits', fruitSchema);
    fruits.find({},function(error,myFruits){
        if(error){
            return console.error(error);
        }
        console.log(myFruits.toString());
    });

  var fruitObj = new fruits({
      ID:1,
      NAME:'Apple',
      DESCRIPTION:'This is Apple'
  });
  fruitObj.save(function(error,myfruits){
      if(error){
          return console.error(error);
      }
      console.log('fruit is saved');
  })
   // callback(result);
});

db.close();



