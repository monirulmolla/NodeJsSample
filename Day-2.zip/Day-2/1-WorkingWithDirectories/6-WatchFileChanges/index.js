console.log("Watch directory changes");
var fs = require('fs');
var fileName ='DirectoryA/fileA.txt';
/*
///////////////////
/////////Step A: watch function
///////////////////
//This watch module is system dependent, so how operating system works it reflects here.
// Operating system is implementing this watch so may see multiple output in the console for the same event
fs.watch(fileName,{persistent:true},function(event,filename){
    console.log("change in watch file:: "+ filename);
});
*/
///////////////////
/////////Step B: watchFile function, to call in interval of micro second.
///////////////////
fs.watchFile(fileName,{persistent:true,interval:5000},function(event,file){
    console.log("change in watch file:: "+ fileName);
});