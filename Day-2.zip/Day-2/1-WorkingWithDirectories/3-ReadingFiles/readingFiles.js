console.log("Reading files");
var fs = require('fs');
///////////
////Step A:Read a file
//////////

//Step A1: Read a file asynchronusly
fs.readFile('DirectoryA/fileA.txt','utf8',function(error,data){
    if(error){
        console.log(error);
    }else{
        console.log("File Read::"+data);
    }
});

//Step A2: Read file synchronusly
var contents = fs.readFileSync('DirectoryA/fileA.txt','utf8');
console.log(contents);