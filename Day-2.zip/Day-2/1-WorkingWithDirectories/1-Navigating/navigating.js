console.log("Navigating through the directory");
var fs = require('fs');
/////////////
/////Step A:Read file from a directory
/////////////

//Step A1:asyncronus reading
fs.readdir('DirectoryA', function(err, files){//to read everything in directory
    if(err){
        console.log(err);
    }else{
        console.log("----------Directory Listing------------");
        files.forEach(function(file){
            var filePath ='DirectoryA/'+ file;
            fs.stat(filePath,function(error,stats){// this stat method is used to check if the file is there in directory
                // and this an asynchronus function
               if(error){
                   console.log(error);
               }else if(stats){
                     if(stats.isFile()){
                         console.log(file+" is a file.");
                     }else if(stats.isDirectory()){
                         console.log(file+" is a directory.");
                     }
               }
            });
        });
    }
});

//Step A2: syncronus reading
//var contentSync = fs.readdirSync('DirectoryA');
//console.log(contentSync);