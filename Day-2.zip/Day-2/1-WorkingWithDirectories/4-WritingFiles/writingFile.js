console.log("Writing to a file");
var fs = require('fs');
///////////
////Step A:Write a file
//////////
var data ="This is a string I am writing to the file";
//var data1 ="This is my second string";

//Step A1: Write a file asynchronusly
fs.writeFile('DirectoryA/fileA.txt',data,function(error){//writeFile will overide the exixting file
    if(error){
        console.log(error);
    }else{
        console.log("File write completed");
    }
});

var data3 ="This is my second string";
//Step A2: Write a file asynchronusly
fs.appendFile('DirectoryA/fileA.txt',data3,function(error){//appendFile will append the file.
    if(error){
        console.log(error);
    }else{
        console.log("Data append completed");
    }
});