console.log("Adding and removing directories");

var fs = require('fs');
fs.mkdir('DirectoryA/DirectoryB',function(error){
    if(error){
        console.log(error);
    }else{
        console.log("Directory created");
    }
});

fs.rmdir('DirectoryA/DirectoryB',function(error){
    if(error){
        console.log(error);
    }else{
        console.log("Directory removed successfully");
    }
});