console.log("Watch directory changes");
var fs = require('fs');
//This watch module is system dependent, so how operating system works it reflects here.
fs.watch('DirectoryA',{persistent:true},function(event,filename){
    if(event =='rename'){
        console.log("rename event in directory:: "+ filename);

    }else if(event =='change'){
        console.log("change event in directory:: "+ filename);
    }
});